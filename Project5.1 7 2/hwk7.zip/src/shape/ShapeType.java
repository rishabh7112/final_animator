package shape;

/**
 * Represents the type of shape in an animation.
 */
public enum ShapeType {
  RECTANGLE, OVAL
}
